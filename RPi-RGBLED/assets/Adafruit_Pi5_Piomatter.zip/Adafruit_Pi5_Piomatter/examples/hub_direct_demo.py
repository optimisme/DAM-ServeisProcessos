#!/usr/bin/env python3
# Minimal HUB75 pulse demo using libgpiod v1 on Raspberry Pi 5 (RP1)
# Matches your wiring (Adafruit-HAT style). Educational only (slow, no PWM).

import time
import gpiod

# --- Your wiring (BCM offsets for gpiochip0) ---
R1, G1, B1 = 5, 13, 6
R2, G2, B2 = 12, 16, 23
A, B, C, D, E = 22, 26, 27, 20, 24
CLK, LAT, OE = 17, 21, 4

ALL = [R1,G1,B1, R2,G2,B2, A,B,C,D,E, CLK,LAT,OE]

def request_output_line(chip, offset, initial=0, name="hub75"):
    line = chip.get_line(offset)
    line.request(consumer=name, type=gpiod.LINE_REQ_DIR_OUT, default_vals=[initial])
    return line

def main():
    chip = gpiod.Chip("gpiochip0")

    # Request all lines as outputs, initial LOW
    lines = { pin: request_output_line(chip, pin, 0) for pin in ALL }

    def set_pin(pin, v):
        lines[pin].set_value(1 if v else 0)

    def pulse(pin):
        lines[pin].set_value(1)
        lines[pin].set_value(0)

    def set_row_addr(row):
        for bit, pin in enumerate([A,B,C,D,E]):
            set_pin(pin, (row >> bit) & 1)

    print("Cycling rows… Ctrl+C to stop.")
    try:
        while True:
            # 1/32 scan for 64x64 (has E). If your panel is 1/16, change to range(16)
            for row in range(32):
                set_row_addr(row)

                # Shift 64 dummy pixels
                for col in range(64):
                    # simple visible pattern
                    set_pin(R1, (col & 1))
                    set_pin(G1, ((~col) & 1))
                    set_pin(B1, 0)
                    set_pin(R2, (row & 1))
                    set_pin(G2, ((~row) & 1))
                    set_pin(B2, 0)
                    pulse(CLK)

                # Latch and brief enable (OE is active-low)
                pulse(LAT)
                set_pin(OE, 0)          # LEDs on
                time.sleep(0.0002)      # ~200 µs
                set_pin(OE, 1)          # LEDs off
            time.sleep(0.02)
    except KeyboardInterrupt:
        pass
    finally:
        # Release all lines
        for ln in lines.values():
            ln.release()
        chip.close()
        print("\nReleased GPIOs. Bye.")

if __name__ == "__main__":
    main()
