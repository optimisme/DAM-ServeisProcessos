// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (c) 2024 Raspberry Pi Ltd.
 * All rights reserved.
 */
#ifndef _HARDWARE_PIO_H
#define _HARDWARE_PIO_H

#include "piolib.h"

#endif
